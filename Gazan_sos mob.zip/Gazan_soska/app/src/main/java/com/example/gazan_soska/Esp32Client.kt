package com.example.gazan_soska.ui

import android.util.Log
import io.ktor.network.selector.ActorSelectorManager
import io.ktor.network.sockets.aSocket
import io.ktor.network.sockets.isClosed
import io.ktor.network.sockets.openReadChannel
import io.ktor.network.sockets.openWriteChannel
import io.ktor.utils.io.ByteReadChannel
import io.ktor.utils.io.ByteWriteChannel
import io.ktor.utils.io.core.readUTF8Line
import io.ktor.utils.io.core.writeFully
import io.ktor.utils.io.writeFully
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.ConnectException

class Esp32Client(
    private val host: String,
    private val port: Int,
    private val coroutineScope: kotlinx.coroutines.CoroutineScope // Передаем Scope из ViewModel
) {

    private var readChannel: ByteReadChannel? = null
    private var writeChannel: ByteWriteChannel? = null
    private var clientSocket: io.ktor.network.sockets.Socket? = null
    private var readJob: Job? = null

    private val _connectionStatus = MutableStateFlow<ConnectionState>(ConnectionState.Disconnected)
    val connectionStatus: StateFlow<ConnectionState> = _connectionStatus

    private val _receivedData = MutableStateFlow<String?>(null)
    val receivedData: StateFlow<String?> = _receivedData

    sealed class ConnectionState {
        object Disconnected : ConnectionState()
        object Connecting : ConnectionState()
        object Connected : ConnectionState()
        data class Error(val message: String) : ConnectionState()
    }

    // Инициализация. Попытка подключения
    init {
        connect()
    }

    fun connect() {
        if (_connectionStatus.value is ConnectionState.Connected || _connectionStatus.value is ConnectionState.Connecting) {
            Log.d("Esp32Client", "Already connected or connecting.")
            return
        }

        _connectionStatus.value = ConnectionState.Connecting
        coroutineScope.launch(Dispatchers.IO) {
            try {
                Log.d("Esp32Client", "Attempting to connect to $host:$port")
                clientSocket = aSocket(ActorSelectorManager(Dispatchers.IO)).tcp().connect(host, port) {
                    // Таймаут подключения
                    socketTimeout = 5000 // 5 секунд
                }
                readChannel = clientSocket?.openReadChannel()
                writeChannel = clientSocket?.openWriteChannel(autoFlush = true)
                _connectionStatus.value = ConnectionState.Connected
                Log.d("Esp32Client", "Connected to $host:$port")
                startReading()
            } catch (e: ConnectException) {
                _connectionStatus.value = ConnectionState.Error("Connection refused: ${e.message}")
                Log.e("Esp32Client", "Connection refused: ${e.message}")
                reconnectDelay()
            } catch (e: IOException) {
                _connectionStatus.value = ConnectionState.Error("Network error: ${e.message}")
                Log.e("Esp32Client", "Network error: ${e.message}")
                reconnectDelay()
            } catch (e: Exception) {
                _connectionStatus.value = ConnectionState.Error("Unknown error: ${e.message}")
                Log.e("Esp32Client", "Unknown error: ${e.message}")
                reconnectDelay()
            }
        }
    }

    private suspend fun reconnectDelay() {
        Log.d("Esp32Client", "Will attempt to reconnect in 5 seconds...")
        delay(5000) // Пауза перед следующей попыткой
        connect() // Повторная попытка
    }

    private fun startReading() {
        readJob?.cancel() // Отменяем предыдущую задачу чтения, если она была
        readJob = coroutineScope.launch(Dispatchers.IO) {
            while (isActive && clientSocket?.isClosed == false) {
                try {
                    val line = readChannel?.readUTF8Line(Int.MAX_VALUE)
                    if (line != null) {
                        Log.d("Esp32Client", "Received: $line")
                        _receivedData.value = line
                    } else {
                        // EOF, канал закрыт
                        Log.d("Esp32Client", "Read channel closed by remote host.")
                        disconnect()
                        break
                    }
                } catch (e: IOException) {
                    Log.e("Esp32Client", "Error reading from socket: ${e.message}")
                    disconnect()
                    break
                } catch (e: Exception) {
                    Log.e("Esp32Client", "Unexpected error during read: ${e.message}")
                    disconnect()
                    break
                }
                delay(10) // Небольшая задержка, чтобы не загружать CPU в бесконечном цикле
            }
        }
    }

    suspend fun send(message: String): Boolean {
        return withContext(Dispatchers.IO) {
            if (_connectionStatus.value is ConnectionState.Connected && writeChannel != null) {
                try {
                    Log.d("Esp32Client", "Sending: $message")
                    writeChannel?.writeFully((message + "\n").toByteArray()) // Добавляем новую строку
                    return@withContext true
                } catch (e: IOException) {
                    Log.e("Esp32Client", "Error sending data: ${e.message}")
                    disconnect()
                    return@withContext false
                } catch (e: Exception) {
                    Log.e("Esp32Client", "Unexpected error during send: ${e.message}")
                    disconnect()
                    return@withContext false
                }
            } else {
                Log.w("Esp32Client", "Not connected, cannot send message.")
                return@withContext false
            }
        }
    }

    fun disconnect() {
        readJob?.cancel()
        readJob = null
        try {
            clientSocket?.close()
            readChannel = null
            writeChannel = null
        } catch (e: IOException) {
            Log.e("Esp32Client", "Error closing socket: ${e.message}")
        } finally {
            _connectionStatus.value = ConnectionState.Disconnected
            Log.d("Esp32Client", "Disconnected from $host:$port")
            // Если соединение потеряно, пытаемся переподключиться
            coroutineScope.launch { reconnectDelay() }
        }
    }
}