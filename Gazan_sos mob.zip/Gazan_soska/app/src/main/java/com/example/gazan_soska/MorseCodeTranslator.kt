package com.example.gazan_soska.ui

object MorseCodeTranslator {

    // Карта для английского языка (текст -> Морзе)
    private val englishToMorseMap = mapOf(
        'A' to ".-", 'B' to "-...", 'C' to "-.-.", 'D' to "-..", 'E' to ".",
        'F' to "..-.", 'G' to "--.", 'H' to "....", 'I' to "..", 'J' to ".---",
        'K' to "-.-", 'L' to ".-..", 'M' to "--", 'N' to "-.", 'O' to "---",
        'P' to ".--.", 'Q' to "--.-", 'R' to ".-.", 'S' to "...", 'T' to "-",
        'U' to "..-", 'V' to "...-", 'W' to ".--", 'X' to "-..-", 'Y' to "-.--",
        'Z' to "--..",
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '\'' to ".----.", '!' to "-.-.--",
        '/' to "-..-.", '(' to "-.--.", ')' to "-.--.-", '&' to ".-...", ':' to "---...",
        ';' to "-.-.-.", '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '_' to "..--.-",
        '"' to ".-..-.", '$' to "...-..-", '@' to ".--.-.",
        ' ' to "/" // Пробел между словами в Морзе часто обозначают как одиночный слэш
    )

    // Обратная карта для английского языка (Морзе -> текст)
    private val morseToEnglishMap = englishToMorseMap.entries.associateBy({ it.value }) { it.key }

    // Карта для русского языка (текст -> Морзе)
    // Используем кодировку из МАС-кодов, так как она наиболее распространена
    private val russianToMorseMap = mapOf(
        'А' to ".-", 'Б' to "-...", 'В' to ".--", 'Г' to "--.", 'Д' to "-..",
        'Е' to ".", 'Ж' to "...-", 'З' to "--..", 'И' to "..", 'Й' to ".---",
        'К' to "-.-", 'Л' to ".-..", 'М' to "--", 'Н' to "-.", 'О' to "---",
        'П' to ".--.", 'Р' to ".-.", 'С' to "...", 'Т' to "-", 'У' to "..-",
        'Ф' to "..-.", 'Х' to "....", 'Ц' to "-.-.", 'Ч' to "---.", 'Ш' to "----",
        'Щ' to "--.-", 'Ъ' to ".--.-.", 'Ы' to "-.--", 'Ь' to "-..-", 'Э' to "..-..",
        'Ю' to "..--", 'Я' to ".-.-",
        // Цифры и знаки препинания такие же, как в английском
        '0' to "-----", '1' to ".----", '2' to "..---", '3' to "...--", '4' to "....-",
        '5' to ".....", '6' to "-....", '7' to "--...", '8' to "---..", '9' to "----.",
        '.' to ".-.-.-", ',' to "--..--", '?' to "..--..", '\'' to ".----.", '!' to "-.-.--",
        '/' to "-..-.", '(' to "-.--.", ')' to "-.--.-", '&' to ".-...", ':' to "---...",
        ';' to "-.-.-.", '=' to "-...-", '+' to ".-.-.", '-' to "-....-", '_' to "..--.-",
        '"' to ".-..-.", '$' to "...-..-", '@' to ".--.-.",
        ' ' to "/"
    )

    // Обратная карта для русского языка (Морзе -> текст)
    private val morseToRussianMap = russianToMorseMap.entries.associateBy({ it.value }) { it.key }

    // --- Перевод текста в азбуку Морзе ---
    fun textToMorse(text: String, isRussian: Boolean = false): String {
        val mapping = if (isRussian) russianToMorseMap else englishToMorseMap
        val result = StringBuilder()

        text.uppercase().forEach { char ->
            if (char.isWhitespace()) {
                result.append(mapping[' '] ?: "") // Пробел между словами
            } else {
                mapping[char]?.let {
                    result.append(it).append(" ") // Код Морзе и пробел между символами
                }
            }
        }
        return result.toString().trim() // Убираем лишний пробел в конце
    }

    // --- Перевод азбуки Морзе в текст ---
    fun morseToText(morse: String, isRussian: Boolean = false): String {
        val mapping = if (isRussian) morseToRussianMap else morseToEnglishMap
        val result = StringBuilder()

        // Разделяем входную строку Морзе на слова по '/' и затем на символы по ' '
        morse.split(" / ").forEach { wordMorse ->
            wordMorse.split(" ").forEach { charMorse ->
                if (charMorse.isNotEmpty()) {
                    mapping[charMorse]?.let {
                        result.append(it)
                    }
                }
            }
            result.append(" ") // Добавляем пробел между словами
        }
        return result.toString().trim() // Убираем лишний пробел в конце
    }
}