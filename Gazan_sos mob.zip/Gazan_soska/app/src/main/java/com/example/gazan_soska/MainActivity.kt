package com.example.gazan_soska

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.gazan_soska.ui.Esp32Client
import com.example.gazan_soska.ui.MainViewModel
import com.example.gazan_soska.ui.theme.Gazan_soskaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Gazan_soskaTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    val vm = remember { MainViewModel() }
                    MorseCodeApp(vm)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MorseCodeApp(viewModel: MainViewModel) {
    val inputText by viewModel.inputText.collectAsState()
    val translatedMorse by viewModel.translatedMorse.collectAsState()
    val receivedMorse by viewModel.receivedMorse.collectAsState()
    val receivedText by viewModel.receivedText.collectAsState()
    val isRussian by viewModel.isRussian.collectAsState()
    val connectionStatus by viewModel.connectionStatus.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Переводчик Азбуки Морзе") })
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()), // Делаем скроллящимся
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Статус соединения
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = when (connectionStatus) {
                        is Esp32Client.ConnectionState.Connected -> MaterialTheme.colorScheme.primaryContainer
                        is Esp32Client.ConnectionState.Connecting -> MaterialTheme.colorScheme.tertiaryContainer
                        is Esp32Client.ConnectionState.Error -> MaterialTheme.colorScheme.errorContainer
                        Esp32Client.ConnectionState.Disconnected -> MaterialTheme.colorScheme.secondaryContainer
                    }
                )
            ) {
                Column(Modifier.padding(8.dp)) {
                    Text(
                        text = "Статус ESP32: ${
                            when (connectionStatus) {
                                is Esp32Client.ConnectionState.Connected -> "Подключено"
                                is Esp32Client.ConnectionState.Connecting -> "Подключение..."
                                is Esp32Client.ConnectionState.Error -> "Ошибка: ${(connectionStatus as Esp32Client.ConnectionState.Error).message}"
                                Esp32Client.ConnectionState.Disconnected -> "Отключено"
                            }
                        }",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (connectionStatus !is Esp32Client.ConnectionState.Connected) {
                        Button(onClick = { viewModel.reconnectEsp32() }, Modifier.fillMaxWidth()) {
                            Text("Повторить подключение")
                        }
                    }
                }
            }

            // Переключатель языка
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Английский")
                Spacer(Modifier.width(8.dp))
                Switch(
                    checked = isRussian,
                    onCheckedChange = { viewModel.onToggleLanguage(it) }
                )
                Spacer(Modifier.width(8.dp))
                Text("Русский")
            }

            // Поле для ввода текста
            OutlinedTextField(
                value = inputText,
                onValueChange = { viewModel.onInputTextChanged(it) },
                label = { Text("Введите текст") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )

            // Отображение переведенной азбуки Морзе
            OutlinedTextField(
                value = translatedMorse,
                onValueChange = {}, // Только для чтения
                label = { Text("Морзе (для отправки)") },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                minLines = 3
            )

            // Кнопка отправки сигнала
            Button(
                onClick = { viewModel.sendMorseSignal() },
                modifier = Modifier.fillMaxWidth(),
                enabled = translatedMorse.isNotEmpty() && connectionStatus is Esp32Client.ConnectionState.Connected
            ) {
                Text("Отправить сигнал Морзе на ESP32")
            }

            Divider(modifier = Modifier.fillMaxWidth())

            // Секция для принятых данных
            Text(
                "Принятые сигналы от ESP32:",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.align(Alignment.Start)
            )

            OutlinedTextField(
                value = receivedMorse,
                onValueChange = {}, // Только для чтения
                label = { Text("Принято Морзе") },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                minLines = 3
            )

            OutlinedTextField(
                value = receivedText,
                onValueChange = {}, // Только для чтения
                label = { Text("Переведено в текст") },
                modifier = Modifier.fillMaxWidth(),
                readOnly = true,
                minLines = 3
            )
        }
    }
}