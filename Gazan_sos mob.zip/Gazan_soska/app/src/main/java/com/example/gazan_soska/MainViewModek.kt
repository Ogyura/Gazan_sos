

package com.example.gazan_soska.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {

    // --- Конфигурация ESP32 ---
    private val esp32Host = "192.168.4.1" // IP-адрес вашей ESP32 в режиме AP
    private val esp32Port = 80            // Порт, на котором ESP32 слушает

    // Клиент для взаимодействия с ESP32
    private val esp32Client = Esp32Client(esp32Host, esp32Port, viewModelScope)

    // --- Состояние UI ---
    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText

    private val _translatedMorse = MutableStateFlow("")
    val translatedMorse: StateFlow<String> = _translatedMorse

    private val _receivedMorse = MutableStateFlow("")
    val receivedMorse: StateFlow<String> = _receivedMorse

    private val _receivedText = MutableStateFlow("")
    val receivedText: StateFlow<String> = _receivedText

    private val _isRussian = MutableStateFlow(false)
    val isRussian: StateFlow<Boolean> = _isRussian

    // Статус соединения с ESP32 (из Esp32Client)
    val connectionStatus: StateFlow<Esp32Client.ConnectionState> = esp32Client.connectionStatus

    init {
        // Запускаем сбор данных от клиента ESP32
        viewModelScope.launch {
            esp32Client.receivedData.collect { data ->
                data?.let {
                    _receivedMorse.value = it // Обновляем принятую азбуку Морзе
                    _receivedText.value = MorseCodeTranslator.morseToText(it, _isRussian.value) // Переводим в текст
                }
            }
        }
    }

    fun onInputTextChanged(newText: String) {
        _inputText.value = newText
        // При изменении входного текста сразу обновляем перевод в Морзе
        _translatedMorse.value = MorseCodeTranslator.textToMorse(newText, _isRussian.value)
    }

    fun onToggleLanguage(isRussian: Boolean) {
        _isRussian.value = isRussian
        // Перепереводим текущий текст, если изменился язык
        _translatedMorse.value = MorseCodeTranslator.textToMorse(_inputText.value, isRussian)
        // Также перепереводим принятый Морзе, если он есть
        if (_receivedMorse.value.isNotEmpty()) {
            _receivedText.value = MorseCodeTranslator.morseToText(_receivedMorse.value, isRussian)
        }
    }

    fun sendMorseSignal() {
        val morseToSend = _translatedMorse.value
        if (morseToSend.isNotEmpty()) {
            viewModelScope.launch {
                val success = esp32Client.send(morseToSend)
                if (!success) {
                    // Обработка ошибки отправки, например, показать Toast
                    println("Failed to send Morse code.")
                }
            }
        }
    }

    // Для ручного переподключения (например, по кнопке)
    fun reconnectEsp32() {
        esp32Client.disconnect() // Отключаемся, чтобы инициировать переподключение
        esp32Client.connect()
    }

    override fun onCleared() {
        super.onCleared()
        esp32Client.disconnect() // Отключаемся при уничтожении ViewModel
    }
}